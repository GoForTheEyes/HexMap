﻿using UnityEditor;
using UnityEngine;

public class TextureArrayWizard : ScriptableWizard {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
